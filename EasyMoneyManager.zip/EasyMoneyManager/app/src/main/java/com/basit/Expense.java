package com.basit;

public class Expense {
    public int id;
    public double amount;
    public String title;
    public String description;
    public int month;
    public int year;
    public int date;
}
