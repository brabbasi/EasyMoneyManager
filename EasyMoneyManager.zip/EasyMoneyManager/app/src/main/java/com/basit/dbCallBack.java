package com.basit;

import java.util.ArrayList;

public interface dbCallBack {
    public void onCallBack( ArrayList debt, double totalDebt, ArrayList expense, double totalExpense, boolean result);
}
