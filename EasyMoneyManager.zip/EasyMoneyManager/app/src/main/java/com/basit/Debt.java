package com.basit;

public class Debt {
    public int id;
    public double amount;
    public String to;
    public String description;
    public int month;
    public int year;
    public int date;
}
